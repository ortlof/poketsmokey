import{j as o}from"./singletons.js";const e=o("goto");export{e as g};
