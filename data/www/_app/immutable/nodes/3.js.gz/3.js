import{g as e}from"../chunks/navigation.js";const o=async()=>{e("/")},r=Object.freeze(Object.defineProperty({__proto__:null,load:o},Symbol.toStringTag,{value:"Module"}));export{r as universal};
